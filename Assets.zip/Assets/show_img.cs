﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using System.IO;
using UnityEngine.UI;

public class show_img : MonoBehaviour
{
    //List<Texture2D> loadTexture = new List<Texture2D>();
    List<Sprite> loadsprite = new List<Sprite>();

    //List<string> filePaths = new List<string>();
    //filePaths = GetImagePath();

    bool flag = true;
    Image myimg;

    public static int i = 0;
    // Start is called before the first frame update
    void Start()
    {
        
    }

    // Update is called once per frame
    void Update()
    {
        
    }


    public void OnClick()
    {
        GameObject img = GameObject.Find("Canvas/Image");
        GameObject Name = GameObject.Find("Canvas/imgName");

        if (i == 0 && flag)
        {
            LoadTexture2Sprite(0);
            flag = false;
        }
        else
        {
            LoadTexture2Sprite(i + 1);
            i = i + 1;
        }
        
        myimg = img.GetComponent<Image>();
        //for (i; i < loadsprite.Count; i++)
        myimg.sprite = loadsprite[0];
        //Name.GetComponent<Text>().text = ;
        

    }

    public void Back()
    {
        GameObject img = GameObject.Find("Canvas/Image");
        LoadTexture2Sprite(i-1);
        myimg = img.GetComponent<Image>();
        //for (i; i < loadsprite.Count; i++)
        myimg.sprite = loadsprite[0];
        i = i - 1;

    }



    public static byte[] getImageByte(string imagePath)
    {
        
        FileStream files = new FileStream(imagePath, FileMode.Open);
        
        byte[] imgByte = new byte[files.Length];
        
        files.Read(imgByte, 0, imgByte.Length);
        
        files.Close();
        
        return imgByte;
    }
    
    
    public static List<string> GetImagePath()
    {
        List<string> filePaths = new List<string>();
        string imgtype = "*.JPG|*.PNG";
        string[] ImageType = imgtype.Split('|');
        for (int i = 0; i < ImageType.Length; i++)
        {
    
            
            string[] dirs = Directory.GetFiles(Application.dataPath + @"/bg_imgs", ImageType[i]);
            
            for (int j = 0; j < dirs.Length; j++)
            {
                filePaths.Add(dirs[j]);
                //Debug.Log("img_path:     " + dirs[j]);
            }
            //Debug.Log("In total" + dirs.Length + "image(s)");
        }
    
        return filePaths;
    }



    // Load one image at a time when the function is called.
    public void LoadTexture2Sprite(int i)
    {
        
       //loadTexture.Clear();
        loadsprite.Clear();

        string filename;
        
       List<string> filePaths = new List<string>();
    
    
        filePaths = GetImagePath();
        
        //for (int i = 0; i < filePaths.Count; i++)
        //{
        Texture2D t2d = new Texture2D(500, 500);
       
       t2d.LoadImage(getImageByte(filePaths[i]));
       
       //loadTexture.Add(t2d);
       
       Sprite sprite = Sprite.Create(t2d, new Rect(0, 0, t2d.width, t2d.height), Vector2.zero);
       
       loadsprite.Add(sprite);

        t2d = null;
        sprite = null;

        //filename = filePaths[i];
        filePaths.Clear();

        //return filenma;

        
    
        //}
    }




    

}
