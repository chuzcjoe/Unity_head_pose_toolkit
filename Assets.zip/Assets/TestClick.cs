﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class TestClick : MonoBehaviour
{
    float old_x = 0.071f;
    float old_y = 1.84f;
    float old_z = 0.63f;

    
    // Start is called before the first frame update
    void Start()
    {
        
    }

    // Update is called once per frame
    void Update()
    {
       
    }

    public void OnClick()
    {

        GameObject rentou = GameObject.Find("rentou");
        rentou.transform.position = new Vector3(old_x, old_y, old_z);
        rentou.transform.rotation = Quaternion.Euler(0, 0, 0);
        rentou.transform.localScale = new Vector3(0.07f, 0.07f, 0.07f);


    }
}
